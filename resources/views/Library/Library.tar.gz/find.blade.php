@extends('Library.template')

@section('leftSladeBar')
    <div class="col-2">
            Left lslade Bar

        <form id="autorsFind" method="POST">
            {{ csrf_field() }}
            <div class="row">
                <div>
                    Поиск по автору
                    <input type="text" name="autors_name" id="autors_name" class="form-control input-lg" placeholder="Enter Autors Name" />
                </div>
                <div>
                    <p>
                        <label for="amount" style="text-align: left">Дипазон цен</label>
                        <input type="text" id="price" readonly style="border:0; color:#f6272f; font-weight:bold;">
                    </p>
                    <div id="price-range"></div>
                </div>
                <div>
                    <p>
                        <label for="amount" >Год издания</label>
                        <input type="text" id="age" readonly style="border:0; color:#406df6; font-weight:bold;">
                    </p>
                    <div id="age-range"></div>
                </div>
                <button class="btn btn-theme margin top10 pull-left" type="submit">ПоискJS</button>
            </div>
        </form>
        <div >

            {{--{!! Form::open(array('action' => array('Library\FindController@test', 'autor'  => $autors_name), 'method' => 'POST')) !!}--}}
            {{--{!! Form::submit('Поиск Lara') !!}--}}
            {{--{!! Form::close() !!}--}}
        </div>
    </div>
@endsection

@section('content')
    {{--<div class="col-9">--}}
        {{--<div class="row">--}}
            {{--<p id="autor"> Content </p>--}}
            {{--<div id="strAutor-summ-panel" >--}}
                 {{--Перечень авторов--}}
            {{--</div>--}}
            {{--<select id="strAutor-summ-panel">--}}
                {{--<option > </option>--}}
            {{--</select>--}}

            {{--<p id="pricemin"> Content </p>--}}
            {{--<p id="pricemax"> Content </p>--}}

            {{--<p id="agemin"> Content </p>--}}
            {{--<p id="agemax"> Content </p>--}}

        {{--</div>--}}
    <div class="col-9">
        <div class="row">
            @if($books)
            @foreach ($books as $key =>$value)
                <div class="col-md-3">
                    <div class="card md-3 box-shadow">
                        <img class="card-img-top" data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail" alt="" style="height: 320px; width: 100%; display: block;" src="{{$value->imageURL}}" data-holder-rendered="true">
                        <div class="card-body">
                            <p class="card-text">{{$value->name}}<br>
                                {{$value->strAutor}}<br>
                                Жанр : {{$value->genre}}<br>
                                Издатество:{{$value->Publishing}}<br>
                                Год :{{$value->YearPublication}}<br>
                                Цена :{{$value->price}}грн.<br>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    {!! Form::open(array('action' => array('Library\BooksController@showBook', $value->name), 'method' => 'get')) !!}
                                    {!! Form::submit('Просмотреть') !!}
                                    {!! Form::close() !!}
                                </div>
                                <small class="text-muted">{{$key}} num</small>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
            <nav>
                <ul class="pagination justify-content-end">
                    {{$books->links('vendor.pagination.bootstrap-4')}}
                </ul>
            </nav>
        </div>
    </div>
    </div>
    @endif
@endsection